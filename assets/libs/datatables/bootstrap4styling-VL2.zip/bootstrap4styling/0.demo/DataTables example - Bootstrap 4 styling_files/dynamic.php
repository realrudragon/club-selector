window._site.forumUser = "";
$(document).ready( function () {
	window._site.comments( $('div.content div.comments'), [] );
} );window._site.page = "extensions\/responsive\/examples\/styling\/bootstrap4.html";

$(document).ready( function () {
	window._site.dynamicLoaded();
} );
